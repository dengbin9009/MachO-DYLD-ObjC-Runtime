
extern int whatsup();
