int bar()
{
	return 1;
}


