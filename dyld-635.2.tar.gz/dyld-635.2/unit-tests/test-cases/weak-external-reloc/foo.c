




int __attribute__((weak)) foo[] = { 1, 2, 3, 4 };
int __attribute__((weak)) bar[] = { 10, 11, 12, 13 };

int* pfoo = &foo[2];

