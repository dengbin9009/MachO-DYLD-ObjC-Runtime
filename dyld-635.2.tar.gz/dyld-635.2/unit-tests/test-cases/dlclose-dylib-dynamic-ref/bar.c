__attribute__((weak))
int mydata;


int bar()
{
	return mydata;
}
